from django.shortcuts import render

# request - all information about what happened on the user's side


def index(request):
    return render(request, "mainapp/index.html")


def products(request):
    return render(request, "mainapp/products.html")


def contact(request):
    return render(request, "mainapp/contact.html")